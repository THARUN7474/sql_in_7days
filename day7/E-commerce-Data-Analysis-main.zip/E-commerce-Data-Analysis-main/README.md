# E-commerce-Data-Analysis
This Data Analysis Project is from SQL Basics to Advanced Mastery course by Priya Bhatia on chaicode.com!

Refer to the attached dataset for your work.

This assignment includes various scenarios requiring you to write SQL queries.

Assignments solutions available in SalesDataAnalysis.sql

